import * as firebase from 'firebase';
import firestore from 'firebase/firestore'

const settings = {timestampsInSnapshots: true};

const config = {
    apiKey: "AIzaSyDDxnRe66m2eqehtmxOUEbvCmpZNHlBR3o",
    authDomain: "create-db-api.firebaseapp.com",
    databaseURL: "https://create-db-api.firebaseio.com",
    projectId: "create-db-api",
    storageBucket: "create-db-api.appspot.com",
    messagingSenderId: "312177156692",
    appId: "1:312177156692:web:dfb6354a5542011e9983c1"
};
firebase.initializeApp(config);

firebase.firestore().settings(settings);

export default firebase;