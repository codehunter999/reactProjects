import * as firebase from 'firebase'
let database;
let firebaseConfig = {
    apiKey: "AIzaSyDkhxkyHPYrxM61_y9kU0krO8ufJqIC9VU",
    authDomain: "friendlyeats-69578.firebaseapp.com",
    databaseURL: "https://friendlyeats-69578.firebaseio.com",
    projectId: "friendlyeats-69578",
    storageBucket: "friendlyeats-69578.appspot.com",
    messagingSenderId: "109396437278",
    appId: "1:109396437278:web:eb5c53a3fbd7f61735410f"
}

export const fire = () => {
   	firebase.initializeApp(firebaseConfig);
 	database = firebase.database()
}