import React from 'react';
import NewsList from './components/NewsList';

const App =() => { 
  return <NewsList/>
};

export default App;




//=========================================================================================================
// 뉴스 API 이용 최초 App 코드
//=========================================================================================================
// import React, { useState } from 'react';
// import axios from 'axios';

// const App = () => {
//   const [data, setData] = useState(null);

//   //async-await 적용
//   const onClick = async () => {
//     try{
//       const response = await axios.get(
//         'https://newsapi.org/v2/top-headlines?country=kr&apiKey=08db394e6e1041a0b766e8d8bce8a823',
//       );
//       setData(response.data);
//     } catch (e){
//       console.log(e);
//     }
//   };
    
  
//   //   axios.get('https://jsonplaceholder.typicado.com/todos/1').then(reponse => {
//   //     setData(reponse.data);
//   //   });
//   // };


//   return (
//     <div>
//       <div>
//         <button onClick={onClick}>불러오기</button>
//       </div>
//       {data && <textarea row={7} value={JSON.stringify(data, null, 2)} />}
//     </div>
//   );
// };

// export default App;
