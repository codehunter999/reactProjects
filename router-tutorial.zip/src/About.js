import React from 'react';
import qs from 'qs';

const About =({location}) => {

    // 이 설정으로 문자열 가장 앞의 ? 생략
    const query = qs.parse(location.search,{
        ignoreQueryPrefix: true
    });

    const showDetail = query.detail === 'true'; //뭐리의 파싱값은 문자열

    return(
        <div>
            <h1>introduce</h1>
            <p>router practice</p>
            {showDetail && <p>detail 값을 true로 설정하셨군요!!</p>}
        </div>
    );
};

export default About;