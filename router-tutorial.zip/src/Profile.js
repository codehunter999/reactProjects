import React from 'react';
import {withRouter} from 'react-router-dom';
import WithRouterSample from './WithRouterSample';

const data ={
    dongcheol:{
        name: "dongcheol",
        description: "developer"
    },
    youhwa:{
        name: "youhwa",
        description: "woman"
    }
};

const Profile = ({match}) => {
    const {username} = match.params;
    const profile = data[username];

    if(!profile){
        return <div>no user</div>;
    }
    return (
        <div>
            <h3>
                {username}({profile.name})
            </h3>
            <p>{profile.description}</p>
            <WithRouterSample/>
        </div>
    );
};

export default Profile;