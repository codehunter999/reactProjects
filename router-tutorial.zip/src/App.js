// import React from 'react';
// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;

import React from 'react';
import {Route,Link,Switch} from 'react-router-dom';
import About from './About';
import Home from './Home';
// import Profile from './Profile';
import Profiles from './Profiles';
import HistorySample from './HistorySample';

const App = () => {
  return(
    <div>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/about">Introduce</Link>
        </li>

        {/*         
        <li>
          <Link to="/profile/dongcheol">velopert profile</Link>
        </li>
        <li>
          <Link to="/profile/youhwa">gildong profile</Link>
        </li>
         */}

        <li>
          <Link to="/profiles">프로필</Link>
        </li>

        <li>
          <Link to="/history">history 예제</Link>
        </li>

      </ul>
      <hr/>
      <Switch>
        <Route path="/" component={Home} exact={true} />
        <Route path={["/about","/info"]} component={About} />
        {/* <Route path="/profile/:username" component={Profile} /> */}
        <Route path="/profiles" component={Profiles}/>
        <Route path="/history" component={HistorySample}/>
        <Route
          //path를 따로 정의하지 않으면 모든 상황에 렌더링 됨
          render={({location}) => (
            <div>
              <h2>이 페이지는 존재하지 않습니다:</h2>
              <p>{location.pathname}</p>
            </div>
          )}
        />
      </Switch>
    </div>
  );
};

export default App;